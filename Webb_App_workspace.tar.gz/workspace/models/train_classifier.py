import sys


def load_data('home/workspace/data/clean_disasterC'):
    conn = sqlite3.connect('clean_disasterC.db')
    df = pd.read_sql('SELECT * FROM MCat', conn)
    df = df.astype(str)
    Xfeatures = df.iloc[:,1]
    ylabels = df.iloc[:,4:]
    X=Xfeatures
    y=ylabels


def tokenize(text):
    # get list of all urls using regex
    detected_urls = re.findall(url_regex, text)
    
    # replace each url in text string with placeholder
    for url in detected_urls:
        text =text.replace(url, "website")

    # tokenize text
    tokens = word_tokenize(text)
    
    # initiate lemmatizer
    lemmatizer = WordNetLemmatizer()

    # iterate through each token
    clean_tokens = []
    for tok in tokens:
        
        # lemmatize, normalize case, and remove leading/trailing white space
        clean_tok = lemmatizer.lemmatize(tok).lower().strip()
        clean_tokens.append(clean_tok)

    return clean_tokens

# test out function

for message in X[:]:
    tokens = tokenize(message)
    print(message)
    print(tokens, '\n')


def build_model():
    pipeline = Pipeline([
    ('vect', CountVectorizer()),
    ('tfidf', TfidfTransformer()),
    ('classifier', MultiOutputClassifier(RandomForestClassifier(random_state=42, class_weight="balanced"))),
    
])


def evaluate_model(model, X_test, Y_test, category_names):
    scores = cross_validate(classifier, x_train, y_train, cv=2, scoring=['f1_weighted'])


def save_model(ETL-ML-pipeline,         C:\Users\debo_\Desktop\ML\disaster\):
    pickle.dump(pipeline, open(filename, 'wb'))


def main():
    if len(sys.argv) == 3:
        C:\Users\debo_\Desktop\ML\disaster\clean_disasterC, C:\Users\debo_\Desktop\ML\disaster\ETL-ML-pipeline = sys.argv[1:]
        print('Loading data...\n    DATABASE: {}'.format( C:\Users\debo_\Desktop\ML\disaster\clean_disasterC))
        X, Y, category_names = load_data( C:\Users\debo_\Desktop\ML\disaster\clean_disasterC)
        X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)
        
        print('Building model...')
        model = build_model()
        
        print('Training model...')
        model.fit(X_train, Y_train)
        
        print('Evaluating model...')
        evaluate_model(model, X_test, Y_test, category_names)

        print('Saving model...\n    MODEL: {}'.format(C:\Users\debo_\Desktop\ML\disaster\ETL-ML-pipeline))
        save_model(model, C:\Users\debo_\Desktop\ML\disaster\ETL-ML-pipeline)

        print('Trained model saved!')

    else:
        print('Please provide the filepath of the disaster messages database '\
              'as the first argument and the filepath of the pickle file to '\
              'save the model to as the second argument. \n\nExample: python '\
              'train_classifier.py ../data/DisasterResponse.db classifier.pkl')


if __name__ == '__main__':
    main()