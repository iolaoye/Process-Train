import sys


def load_data(home/workspace/data/disaster_messages.csv, home/workspace/data/disaster_categories):
messages = pd.read_csv(home/workspace/data/disaster_messages.csv")
categories = pd.read_csv(home/workspace/data/disaster_categories.csv")

def clean_data(df):
    # merge datasets
df=pd.merge(messages, categories, on="id")
#Split categories into separate category columns.
# create a dataframe of the 36 individual category columns
#df_final['categories'].str.split(';', expand=True)
categories = df['categories'].str.split(';', expand=True)
categories.head()
row = categories.iloc[0]
# select the first row of the categories dataframe

row_1=categories.head(1)
row = categories.iloc[0]
categories.columns=row
# use this row to extract a list of new column names for categories.
# one way is to apply a lambda function that takes everything 
# up to the second to last character of each string with slicing
category_colnames = categories.columns
print(category_colnames)
# rename the columns of `categories`
categories.columns = category_colnames
categories.head()
#Convert category values to just numbers 0 or 1
for column in categories:
    # set each value to be the last character of the string
    categories[column] = df.categories.astype(str).str[-1:]
    
# convert column from string to numeric
categories[column] =  categories[column].astype(np.int64)
#Replace categories column in df with new category columns.
# drop the original categories column from `df`
df.drop('categories', axis=1, inplace=True)
# concatenate the original dataframe with the new `categories` dataframe 
df = pd.concat([df, categories], axis =1)
#to display the first duplicate rows instead of the last
duplicateRows_first = df[df.duplicated(keep='last')]
# drop duplicates
df = df.drop_duplicates(keep='first')


def save_data(df, clean_disasterC.dbe):
    engine = create_engine('sqlite:///clean_disasterC.db')
    df.to_sql('MCat', engine, index=False)   


def main():
    if len(sys.argv) == 4:

        home/workspace/data/disaster_messages, home/workspace/data/disaster_categories, home/workspace/data/clean_disasterC = sys.argv[1:]

        print('Loading data...\n    MESSAGES: {}\n    CATEGORIES: {}'
              .format(home/workspace/data/disaster_categories))
        df = load_data(home/workspace/data/disaster_messages, home/workspace/data/disaster_categories)

        print('Cleaning data...')
        df = clean_data(df)
        
        print('Saving data...\n    DATABASE: {}'.format(home/workspace/data/clean_disasterC))
        save_data(df, home/workspace/data/clean_disasterC)
        
        print('Cleaned data saved to database!')
    
    else:
        print('Please provide the filepaths of the messages and categories '\
              'datasets as the first and second argument respectively, as '\
              'well as the filepath of the database to save the cleaned data '\
              'to as the third argument. \n\nExample: python process_data.py '\
              'disaster_messages.csv disaster_categories.csv '\
              'DisasterResponse.db')


if __name__ == '__main__':
    main()